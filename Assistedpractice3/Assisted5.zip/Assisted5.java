package assistedproject3.java;
class ListNode {

    int data;

    ListNode next;



    public ListNode(int data) {

        this.data = data;

        this.next = null;

    }

}



class LinkedList {

    private ListNode head;



    public LinkedList() {

        head = null;

    }



    // Method to insert a new node at the end of the linked list

    public void insert(int data) {

        ListNode newNode = new ListNode(data);



        if (head == null) {

            head = newNode;

        } else {

            ListNode current = head;

            while (current.next != null) {

                current = current.next;

            }

            current.next = newNode;

        }

    }



    

    public void delete(int key) {

        if (head == null) {

            return; 

        }



        if (head.data == key) {

            head = head.next; 

            return;

        }



        ListNode current = head;

        ListNode previous = null;



        while (current != null && current.data != key) {

            previous = current;

            current = current.next;

        }



        if (current != null) {

            

            previous.next = current.next;

        }

    }



   

    public void display() {

        ListNode current = head;

        while (current != null) {

            System.out.print(current.data + " ");

            current = current.next;

        }

        System.out.println();

    }

}



public class Assisted5 {

    public static void main(String[] args) {

        LinkedList list = new LinkedList();



       

        list.insert(10);

        list.insert(20);

        list.insert(30);

        list.insert(40);

        list.insert(50);



        System.out.println("Original Linked List:");

        list.display();



        int keyToDelete = 30;

        list.delete(keyToDelete);



        System.out.println("Linked List after deleting first occurrence of " + keyToDelete + ":");

        list.display();

    }

}

