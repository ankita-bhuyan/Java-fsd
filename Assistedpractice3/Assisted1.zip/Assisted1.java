package assistedproject3.java;

public class Assisted1 {

    public static void main(String[] args) {

        int[] originalArray = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

        int rotateSteps = 5;



        
        rotateSteps = rotateSteps % originalArray.length;



        int[] rotatedArray = new int[originalArray.length];



        

        for (int i = 0; i < rotateSteps; i++) {

            rotatedArray[i] = originalArray[originalArray.length - rotateSteps + i];

        }



        

        for (int i = rotateSteps; i < originalArray.length; i++) {

            rotatedArray[i] = originalArray[i - rotateSteps];

        }



        System.out.println("Original Array: ");

        for (int num : originalArray) {

            System.out.print(num + " ");

        }



        System.out.println("\nRotated Array: ");

        for (int num : rotatedArray) {

            System.out.print(num + " ");

        }

    }

}



