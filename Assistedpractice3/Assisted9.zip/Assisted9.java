package assistedproject3.java;


import java.util.LinkedList;

import java.util.Queue;



public class Assisted9 {

    public static void main(String[] args) {

        // Create a queue

        Queue<Integer> queue = new LinkedList<>();



        // Enqueue elements into the queue (insert)

        queue.offer(10);

        queue.offer(20);

        queue.offer(30);

        queue.offer(40);

        queue.offer(50);



        System.out.println("Queue after enqueuing elements: " + queue);



        // Dequeue elements from the queue (remove)

        int dequeuedElement = queue.poll();

        System.out.println("Dequeued element: " + dequeuedElement);



        System.out.println("Queue after dequeuing an element: " + queue);



        // Peek at the front element without removing it

        int frontElement = queue.peek();

        System.out.println("Front element (without removing): " + frontElement);



        System.out.println("Queue after peeking at the front element: " + queue);

    }

}


