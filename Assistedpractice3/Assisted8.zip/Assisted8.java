package assistedproject3.java;





import java.util.Stack;



public class Assisted8 {

    public static void main(String[] args) {

        // Create a stack

        Stack<Integer> stack = new Stack<>();



        // Push elements onto the stack (insert)

        stack.push(10);

        stack.push(20);

        stack.push(30);

        stack.push(40);

        stack.push(50);



        System.out.println("Stack after pushing elements: " + stack);



        // Pop elements from the stack (remove)

        int poppedElement = stack.pop();

        System.out.println("Popped element: " + poppedElement);



        System.out.println("Stack after popping an element: " + stack);



        // Peek at the top element without removing it

        int topElement = stack.peek();

        System.out.println("Top element (without removing): " + topElement);



        System.out.println("Stack after peeking at the top element: " + stack);

    }

}

