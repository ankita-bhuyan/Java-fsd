package assistedproject.java;
public class Constructor{

    

    

    public Constructor() {

        System.out.println("Default Constructor called.");

    }



   

    public Constructor(String message) {

        System.out.println("Parameterized Constructor called with message: " + message);

    }



    public Constructor(int value) {

        this("Hello"); 

        System.out.println("Parameterized Constructor called with value: " + value);

    }



    public static void main(String[] args) {

  



        Constructor obj1 = new Constructor();



        Constructor obj2 = new Constructor("Welcome!");



        Constructor obj3 = new Constructor(42);

    }

}

