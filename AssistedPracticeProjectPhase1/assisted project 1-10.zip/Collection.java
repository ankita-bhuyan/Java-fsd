package assistedproject.java;
import java.util.ArrayList;
import java.util.HashSet;

import java.util.HashMap;

import java.util.Iterator;

import java.util.List;

import java.util.Set;

import java.util.Map;



public class Collection{



    public static void main(String[] args) {

        

        List<String> arrayList = new ArrayList<>();



       

        arrayList.add("Apple");

        arrayList.add("Banana");

        arrayList.add("Cherry");

        arrayList.add("Date");



        System.out.println("ArrayList Elements:");

        for (String fruit : arrayList) {

            System.out.println(fruit);

        }



        Set<Integer> hashSet = new HashSet<>();



       

        hashSet.add(10);

        hashSet.add(20);

        hashSet.add(30);

        hashSet.add(20); 



        System.out.println("\nHashSet Elements:");

        for (int num : hashSet) {

            System.out.println(num);

        }



        

        Map<String, Integer> hashMap = new HashMap<>();



      

        hashMap.put("One", 1);

        hashMap.put("Two", 2);

        hashMap.put("Three", 3);



        System.out.println("\nHashMap Elements:");

     

        Iterator<Map.Entry<String, Integer>> iterator = hashMap.entrySet().iterator();

        while (iterator.hasNext()) {

            Map.Entry<String, Integer> entry = iterator.next();

            System.out.println(entry.getKey() + ": " + entry.getValue());

        }

    }

}


