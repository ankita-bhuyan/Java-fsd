package assistedproject.java;

public class implict {
	
	    public static void main(String[] args) {
	        
	        int intValue = 10987;
	        double doubleValue = intValue; 
	        System.out.println("Implicit casting: int to double - " + doubleValue);

	        	        double doubleNum = 985.75;
	        int intNum = (int) doubleNum; 
	        System.out.println("Explicit casting: double to int - " + intNum);

	       
	        double doubleValue2 = 1234.5678;
	        int truncatedInt = (int) doubleValue2; 
	        System.out.println("Explicit casting with truncation: double to int - " + truncatedInt);
	    }
	}



