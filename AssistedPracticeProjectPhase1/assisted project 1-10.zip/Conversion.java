package assistedproject.java;

public class Conversion {



    public static void main(String[] args) {

      

        String originalString = "Hello, World!";



   

        StringBuffer stringBuffer = new StringBuffer(originalString);



      

        stringBuffer.append(" Welcome to Java.");



        

        String stringFromBuffer = stringBuffer.toString();



    

        StringBuilder stringBuilder = new StringBuilder(originalString);



      

        stringBuilder.append(" Have a nice day!");



        

        String stringFromBuilder = stringBuilder.toString();



        System.out.println("Original String: " + originalString);

        System.out.println("StringBuffer: " + stringFromBuffer);

        System.out.println("StringBuilder: " + stringFromBuilder);

    }

}



