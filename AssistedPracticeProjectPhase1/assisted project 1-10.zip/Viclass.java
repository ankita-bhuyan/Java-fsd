package assistedproject.java;

public class Viclass {

    

    class MemberInner {

        public void display() {

            System.out.println("This is a Member Inner Class.");

        }

    }



   

    static class StaticNested {

        public void display() {

            System.out.println("This is a Static Nested Class.");

        }

    }



    

    public void methodWithLocalInner() {

        class LocalInner {

            public void display() {

                System.out.println("This is a Local Inner Class.");

            }

        }



        LocalInner localInner = new LocalInner();

        localInner.display();

    }



    interface Greeting {

        void greet();

    }



    public void anonymousInnerDemo() {

        Greeting greeting = new Greeting() {

            @Override

            public void greet() {

                System.out.println("Hello from Anonymous Inner Class!");

            }

        };



        greeting.greet();

    }



    public static void main(String[] args) {

  



        Viclass outer = new Viclass ();



    

        MemberInner memberInner = outer.new MemberInner();

        memberInner.display();



      

        StaticNested staticNested = new StaticNested();

        staticNested.display();





        outer.methodWithLocalInner();



       

        outer.anonymousInnerDemo();

    }

}



