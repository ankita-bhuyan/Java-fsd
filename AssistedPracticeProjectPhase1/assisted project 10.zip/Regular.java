package assistedproject.java;

import java.util.regex.Matcher;

import java.util.regex.Pattern;



public class Regular {



    public static void main(String[] args) {

        

        String text = "The quick brown fox jumps over the lazy dog.";



   

        String pattern = "fox";



        Pattern compiledPattern = Pattern.compile(pattern);



       

        Matcher matcher = compiledPattern.matcher(text);



      

        System.out.println("Finding matches:");

        while (matcher.find()) {

            System.out.println("Match found at index " + matcher.start() + ": " + matcher.group());

        }



      

        String replacedText = matcher.replaceAll("cat");

        System.out.println("\nText after replacement:\n" + replacedText);



       

        String input = "amit,Sumit,amit.sumit@email.com";

        String regex = "(.*),(.*),(.*)";



        Pattern pattern2 = Pattern.compile(regex);

        Matcher matcher2 = pattern2.matcher(input);



        System.out.println("\nUsing capturing groups:");

        if (matcher2.matches()) {

            System.out.println("First Name: " + matcher2.group(1));

            System.out.println("Last Name: " + matcher2.group(2));

            System.out.println("Email: " + matcher2.group(3));

        }

    }

}






