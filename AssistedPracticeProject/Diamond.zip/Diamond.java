package assistedproject2;


interface Animal {
 void eat();
 void sleep();
}


class Dog implements Animal {
 
 public void eat() {
     System.out.println("Dog is eating");
 }


 public void sleep() {
     System.out.println("Dog is sleeping");
 }
}

class Cat implements Animal {
 
 public void eat() {
     System.out.println("Cat is eating");
 }

 
 public void sleep() {
     System.out.println("Cat is sleeping");
 }
}


class Pet extends Dog implements Animal {

 public void eat() {
     super.eat(); // Call the eat method of the Dog class
 }

 
 public void sleep() {
     super.sleep(); // Call the sleep method of the Dog class
 }
}

public class Diamond {
 public static void main(String[] args) {
     Pet pet = new Pet();
     pet.eat();
     pet.sleep();
 }
}
