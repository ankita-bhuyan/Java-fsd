package assistedproject2;

class BankAccount {
    private double balance;

    public BankAccount(double initialBalance) {
        this.balance = initialBalance;
    }
    public synchronized void deposit(double amount) {
        balance += amount;
        System.out.println("Deposited $" + amount + " - New balance: $" + balance);
    }

    public synchronized void withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
            System.out.println("Withdrawn $" + amount + " - New balance: $" + balance);
        } else {
            System.out.println("Insufficient balance for withdrawal.");
        }
    }
}

class TransactionThread extends Thread {
    private BankAccount account;
    private double amount;
    private boolean isDeposit;

    public TransactionThread(BankAccount account, double amount, boolean isDeposit) {
        this.account = account;
        this.amount = amount;
        this.isDeposit = isDeposit;
    }

    @Override
    public void run() {
        if (isDeposit) {
            account.deposit(amount);
        } else {
            account.withdraw(amount);
        }
    }
}

public class Synchronized {
    public static void main(String[] args) {
        BankAccount account = new BankAccount(1000.0);

        TransactionThread depositThread = new TransactionThread(account, 200.0, true);
        TransactionThread withdrawThread1 = new TransactionThread(account, 500.0, false);
        TransactionThread withdrawThread2 = new TransactionThread(account, 300.0, false);

        depositThread.start();
        withdrawThread1.start();
        withdrawThread2.start();
    }
}
