package assistedproject2;

public class SleepWait {

    public static void main(String[] args) {
        final Object lock = new Object();

        
        Thread thread1 = new Thread(() -> {
            System.out.println("Thread 1: Starting...");
            try {
                Thread.sleep(2000); 
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("Thread 1: Woke up after sleep.");
        });

        
        Thread thread2 = new Thread(() -> {
            synchronized (lock) {
                System.out.println("Thread 2: Waiting for a notification...");
                try {
                    lock.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println("Thread 2: Got notified.");
            }
        });

        thread1.start();
        thread2.start();

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

       
        synchronized (lock) {
            System.out.println("Main Thread: Notifying thread 2...");
            lock.notify();
        }
    }
}
