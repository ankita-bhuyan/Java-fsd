package assistedproject2;
class Vehicle {
    
    private String brand;
    private String model;
    private int year;

    
    public Vehicle(String brand, String model, int year) {
        this.brand = brand;
        this.model = model;
        this.year = year;
    }

    
   
    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    
    public void displayInfo() {
        System.out.println("Vehicle Info:");
        System.out.println("Brand: " + brand);
        System.out.println("Model: " + model);
        System.out.println("Year: " + year);
    }
}


class Car extends Vehicle {
    private int numDoors;

    public Car(String brand, String model, int year, int numDoors) {
        super(brand, model, year);
        this.numDoors = numDoors;
    }

    
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Number of Doors: " + numDoors);
    }
}

public class Person {
    public static void main(String[] args) {
       
        Vehicle vehicle = new Vehicle("Toyota", "Camry", 2020);
        Car car = new Car("Honda", "Civic", 2021, 4);

        
        vehicle.setYear(2022);

       
        System.out.println("Vehicle Information:");
        vehicle.displayInfo();

        System.out.println("\nCar Information:");
        car.displayInfo();
    }
}