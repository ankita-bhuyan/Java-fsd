package assistedproject2;
class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}

public class Throw {
    public static void main(String[] args) {
        try {
            int result = divide(10, 0); // Attempt to divide by zero
            System.out.println("Result: " + result);
        } catch (CustomException ce) {
            System.err.println("Custom Exception: " + ce.getMessage());
        } catch (ArithmeticException ae) {
            System.err.println("Arithmetic Exception: Cannot divide by zero.");
        } finally {
            System.out.println("Finally block executed.");
        }
    }

    public static int divide(int dividend, int divisor) throws CustomException {
        if (divisor == 0) {
            throw new CustomException("Division by zero is not allowed.");
        }
        return dividend / divisor;
    }
}
