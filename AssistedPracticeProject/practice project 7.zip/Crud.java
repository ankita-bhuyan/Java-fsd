package assistedproject2;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Crud{

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        while (true) {
            System.out.println("Choose an operation:");
            System.out.println("1. Create a file");
            System.out.println("2. Read a file");
            System.out.println("3. Update a file");
            System.out.println("4. Delete a file");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            
            int choice = scanner.nextInt();
            
            switch (choice) {
                case 1:
                    createFile();
                    break;
                case 2:
                    readFile();
                    break;
                case 3:
                    updateFile();
                    break;
                case 4:
                    deleteFile();
                    break;
                case 5:
                    System.out.println("Exiting the program.");
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    public static void createFile() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the file name to create: ");
        String fileName = scanner.next();
        
        try {
            File file = new File(fileName);
            if (file.createNewFile()) {
                System.out.println("File created successfully: " + file.getAbsolutePath());
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.err.println("Error creating the file: " + e.getMessage());
        }
    }

    public static void readFile() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the file name to read: ");
        String fileName = scanner.next();
        
        try (FileReader reader = new FileReader(fileName)) {
            int data;
            while ((data = reader.read()) != -1) {
                System.out.print((char) data);
            }
            System.out.println("\nFile read successfully.");
        } catch (IOException e) {
            System.err.println("Error reading the file: " + e.getMessage());
        }
    }

    public static void updateFile() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the file name to update: ");
        String fileName = scanner.next();
        
        try (FileWriter writer = new FileWriter(fileName, true)) {
            System.out.println("Enter text to append (Enter 'q' to exit):");
            scanner.nextLine(); // Consume the newline character from previous input
            String text;
            while (!(text = scanner.nextLine()).equals("q")) {
                writer.write(text + "\n");
            }
            System.out.println("File updated successfully.");
        } catch (IOException e) {
            System.err.println("Error updating the file: " + e.getMessage());
        }
    }

    public static void deleteFile() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the file name to delete: ");
        String fileName = scanner.next();
        
        File file = new File(fileName);
        if (file.delete()) {
            System.out.println("File deleted successfully.");
        } else {
            System.out.println("Failed to delete the file. It may not exist.");
        }
    }
}
